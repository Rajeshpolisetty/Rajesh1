# NewsFlow - Modern News App

A beautiful, modern news application with Instagram Reels-style vertical swiping. Built with React and designed for mobile-first browsing.

## Features

- **Vertical Swiping**: Swipe up and down to navigate through news stories (like Instagram Reels)
- **Keyboard Navigation**: Use arrow keys (up/down) for desktop browsing
- **Interactive Engagement**: Like, comment, share, and bookmark stories
- **Responsive Design**: Optimized for mobile, tablet, and desktop
- **Smooth Animations**: 500ms transitions between stories
- **Modern UI**: Dark theme with gradient accents
- **Touch Support**: Full touch gesture support for mobile devices

## Tech Stack

- **React 18**: UI framework
- **Lucide React**: Beautiful icon library
- **CSS3**: Custom styling and animations
- **JavaScript ES6+**: Modern JavaScript

## Getting Started

### Prerequisites

- Node.js (v14 or higher)
- npm or yarn package manager

### Installation

1. Clone the repository:
```bash
git clone <repository-url>
cd newsflow-app
```

2. Install dependencies:
```bash
npm install
```

3. Start the development server:
```bash
npm start
```

4. Open [http://localhost:3000](http://localhost:3000) to view in the browser

## Usage

### Navigation
- **Mobile**: Swipe up/down to move between stories
- **Desktop**: Use arrow keys (↑ ↓) or click navigation dots
- **Tap dots**: Click the dots at the bottom to jump to specific stories

### Interactions
- **Heart**: Like a story
- **Comment**: View comments (click to interact)
- **Share**: Share the story
- **Bookmark**: Save stories for later

## Project Structure

```
newsflow-app/
├── public/
│   └── index.html
├── src/
│   ├── components/
│   │   └── NewsApp.js
│   ├── styles/
│   │   └── NewsApp.css
│   ├── App.js
│   ├── App.css
│   ├── index.js
│   └── index.css
├── package.json
└── README.md
```

## Deployment

### Deploy to Vercel (Recommended)

1. Install Vercel CLI:
```bash
npm i -g vercel
```

2. Deploy:
```bash
vercel
```

### Deploy to Netlify

1. Build the app:
```bash
npm run build
```

2. Connect your repository to Netlify and it will auto-deploy

### Deploy to Heroku

1. Create a Heroku account and install CLI

2. Build for production:
```bash
npm run build
```

3. Deploy using Heroku CLI:
```bash
heroku create your-app-name
git push heroku main
```

### Deploy to GitHub Pages

1. Add to package.json:
```json
"homepage": "https://yourusername.github.io/newsflow-app"
```

2. Install gh-pages:
```bash
npm install --save-dev gh-pages
```

3. Add deploy scripts to package.json:
```json
"scripts": {
  "predeploy": "npm run build",
  "deploy": "gh-pages -d build"
}
```

4. Deploy:
```bash
npm run deploy
```

## Customization

### Adding More News Stories

Edit `src/components/NewsApp.js` and add to the `newsStories` array:

```javascript
{
  id: 6,
  category: 'POLITICS',
  title: 'Your headline here',
  description: 'Your story description',
  author: 'Author Name',
  timestamp: '2 hours ago',
  image: 'linear-gradient(135deg, #color1 0%, #color2 100%)',
  comments: 0,
  shares: 0,
  likes: 0,
}
```

### Connecting to a Real API

Replace the static `newsStories` array with API calls:

```javascript
useEffect(() => {
  fetch('your-api-endpoint')
    .then(res => res.json())
    .then(data => setNewsStories(data))
}, []);
```

### Changing Colors

Edit `src/styles/NewsApp.css` to customize the color scheme. Key colors:
- Primary: `#60a5fa` (blue)
- Accent: `#06b6d4` (cyan)
- Like: `#ef4444` (red)
- Save: `#fbbf24` (yellow)

## Available Scripts

```bash
npm start          # Run development server
npm run build      # Build for production
npm test           # Run tests
npm run eject      # Eject from Create React App
```

## Browser Support

- Chrome/Edge (latest)
- Firefox (latest)
- Safari (latest)
- Mobile browsers (iOS Safari, Chrome Mobile)

## Performance Tips

- Lazy load images in production
- Implement pagination for large news feeds
- Add service workers for offline support
- Compress images and use modern formats (WebP)

## Future Enhancements

- [ ] Backend API integration
- [ ] User authentication
- [ ] Personalized news feed
- [ ] Dark/Light theme toggle
- [ ] Push notifications
- [ ] Offline reading
- [ ] Search functionality
- [ ] Category filtering
- [ ] Infinite scroll
- [ ] Comments system

## License

MIT License - feel free to use this project for personal or commercial purposes.

## Support

For issues or questions, please open an issue in the repository.

---

Built with ❤️ by NewsFlow Team
