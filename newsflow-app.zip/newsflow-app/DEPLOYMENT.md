# NewsFlow Deployment Guide

Complete guide to deploy NewsFlow to various platforms.

## Quick Start - Local Development

```bash
npm install
npm start
```

Visit `http://localhost:3000`

## Production Build

```bash
npm run build
```

This creates an optimized production build in the `build/` folder.

---

## 1. Deploy to Vercel (Recommended ⭐)

**Vercel is the easiest option - auto-deploys from GitHub**

### Option A: Using GitHub (Recommended)

1. Push your code to GitHub
2. Go to [vercel.com](https://vercel.com)
3. Click "New Project"
4. Import your GitHub repository
5. Click "Deploy"
6. Your app is live! 🎉

**URL**: `https://newsflow-app.vercel.app`

### Option B: Using CLI

```bash
npm i -g vercel
vercel
```

Follow the prompts. Your app will be deployed instantly.

---

## 2. Deploy to Netlify

### Option A: Using GitHub (Recommended)

1. Push code to GitHub
2. Go to [netlify.com](https://netlify.com)
3. Click "New site from Git"
4. Connect GitHub account
5. Select repository
6. Build settings:
   - Build command: `npm run build`
   - Publish directory: `build`
7. Click "Deploy site"

### Option B: Using CLI

```bash
npm install -g netlify-cli
netlify deploy --prod --dir=build
```

### Option C: Drag & Drop

```bash
npm run build
```

Then drag the `build` folder to [netlify.com/drop](https://netlify.com/drop)

---

## 3. Deploy to Firebase Hosting

```bash
npm install -g firebase-tools
firebase login
firebase init hosting
```

When prompted:
- Public directory: `build`
- Rewrite URLs: Yes
- Overwrite: No

```bash
npm run build
firebase deploy
```

---

## 4. Deploy to AWS Amplify

```bash
npm install -g @aws-amplify/cli
amplify configure
amplify init
amplify publish
```

Or connect GitHub in AWS Amplify Console for auto-deployment.

---

## 5. Deploy to GitHub Pages

### Step 1: Update package.json

```json
{
  "homepage": "https://yourusername.github.io/newsflow-app"
}
```

### Step 2: Install gh-pages

```bash
npm install --save-dev gh-pages
```

### Step 3: Add deploy scripts

```json
"scripts": {
  "predeploy": "npm run build",
  "deploy": "gh-pages -d build",
  "start": "react-scripts start"
}
```

### Step 4: Deploy

```bash
npm run deploy
```

Your site will be live at: `https://yourusername.github.io/newsflow-app`

---

## 6. Deploy to Heroku

### Prerequisites
- Heroku account
- Heroku CLI installed

### Steps

```bash
heroku login
heroku create your-app-name
npm run build
git push heroku main
```

Or use GitHub integration in Heroku Dashboard for auto-deployment.

---

## 7. Deploy to Render

1. Go to [render.com](https://render.com)
2. Click "New" → "Web Service"
3. Connect GitHub repository
4. Settings:
   - Build command: `npm install && npm run build`
   - Start command: `npm start`
   - Environment: Node
5. Deploy

---

## 8. Deploy to Railway

1. Go to [railway.app](https://railway.app)
2. Click "New Project"
3. Import GitHub repo
4. Railway auto-detects React
5. Deploy automatically

---

## 9. Deploy as Docker Container

### Create Dockerfile

```dockerfile
FROM node:18-alpine
WORKDIR /app
COPY package.json package-lock.json ./
RUN npm install
COPY . .
RUN npm run build
EXPOSE 3000
CMD ["npm", "start"]
```

### Build & Run

```bash
docker build -t newsflow-app .
docker run -p 3000:3000 newsflow-app
```

### Push to Docker Hub

```bash
docker tag newsflow-app yourusername/newsflow-app
docker push yourusername/newsflow-app
```

---

## 10. Deploy to Traditional Hosting (cPanel, etc.)

### Step 1: Build for production

```bash
npm run build
```

### Step 2: Upload files

- Upload `build` folder contents to `public_html` via FTP
- Rename `public_html` to `public_html_old` (backup)
- Rename `build` to `public_html`

### Step 3: Configure .htaccess

Create `.htaccess` in root:

```apache
<IfModule mod_rewrite.c>
  RewriteEngine On
  RewriteBase /
  RewriteRule ^index\.html$ - [L]
  RewriteCond %{REQUEST_FILENAME} !-f
  RewriteCond %{REQUEST_FILENAME} !-d
  RewriteRule . /index.html [L]
</IfModule>
```

---

## Environment Variables

Create `.env` file in root:

```env
REACT_APP_API_URL=https://api.example.com
REACT_APP_NEWS_API_KEY=your_key_here
```

**Available platforms handle env vars differently:**

- **Vercel**: Add in Project Settings → Environment Variables
- **Netlify**: Add in Site Settings → Build & Deploy → Environment
- **Heroku**: Use Dashboard or `heroku config:set KEY=VALUE`
- **GitHub Pages**: Limited (no secret env vars supported)

---

## Domain Configuration

### Connect Custom Domain

1. **Vercel**: Settings → Domains → Add custom domain
2. **Netlify**: Site settings → Domain management → Add custom domain
3. **Heroku**: Settings → Domains → Add domain
4. Update DNS records at your registrar

### HTTPS/SSL

All platforms provide free SSL certificates automatically.

---

## Monitoring & Analytics

### Add Google Analytics

```bash
npm install react-ga
```

Add to `src/App.js`:

```javascript
import ReactGA from 'react-ga';

ReactGA.initialize('GA_TRACKING_ID');
ReactGA.pageview(window.location.pathname);
```

### Error Tracking

Use Sentry for error monitoring:

```bash
npm install @sentry/react
```

---

## Performance Optimization

### Before Deployment

1. **Optimize images**: Use WebP format
2. **Code splitting**: Use React.lazy()
3. **Minification**: `npm run build` does this
4. **Caching**: Set proper cache headers

### Check Build Size

```bash
npm install -g source-map-explorer
npm run build
source-map-explorer 'build/static/js/*.js'
```

---

## Troubleshooting

### Build fails
```bash
rm -rf node_modules package-lock.json
npm install
npm run build
```

### Routes not working
Make sure your platform supports SPA routing (most do). For traditional hosting, use `.htaccess` configuration above.

### Environment variables not loading
Check your platform's env var syntax - some use `REACT_APP_` prefix requirement.

### Port already in use
```bash
# Find process using port 3000
lsof -i :3000
# Kill it
kill -9 <PID>
```

---

## Recommended Deployment Stack

**For beginners**: Vercel or Netlify (easiest)
**For production**: Vercel + GitHub (auto-deploys on push)
**For enterprise**: AWS Amplify or Firebase
**For serverless**: Netlify Functions or Vercel Serverless

---

## Cost Comparison

| Platform | Free Tier | Best For |
|----------|-----------|----------|
| Vercel | ✅ Yes | Production |
| Netlify | ✅ Yes | Production |
| GitHub Pages | ✅ Yes | Portfolio/Static |
| Firebase | ✅ Limited | Startups |
| Heroku | ❌ No | Legacy |
| AWS | ✅ Limited | Enterprise |

---

## Next Steps

1. Choose a platform (Vercel recommended)
2. Follow deployment steps
3. Add custom domain
4. Set up analytics
5. Configure CI/CD for auto-deployment

**Happy deploying! 🚀**
