import React from 'react';
import NewsApp from './components/NewsApp';
import './App.css';

function App() {
  return <NewsApp />;
}

export default App;
