import React, { useState, useRef, useEffect } from 'react';
import { Heart, MessageCircle, Share2, Bookmark, Home, Bell, Mail, Zap } from 'lucide-react';
import '../styles/NewsApp.css';

const NewsApp = () => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [liked, setLiked] = useState({});
  const [saved, setSaved] = useState({});
  const [touchStart, setTouchStart] = useState(0);
  const [touchEnd, setTouchEnd] = useState(0);
  const containerRef = useRef(null);

  const newsStories = [
    {
      id: 1,
      category: 'TECHNOLOGY',
      title: 'AI Revolution Transforms Global Workforce',
      description: 'New developments in artificial intelligence are reshaping how we work, creating both unprecedented opportunities and challenges across industries.',
      author: 'Sarah Chen',
      timestamp: '2 hours ago',
      image: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
      comments: 2847,
      shares: 1523,
      likes: 5432,
    },
    {
      id: 2,
      category: 'BUSINESS',
      title: 'Tech Giants Report Record-Breaking Earnings',
      description: 'Major technology companies announce quarterly earnings that exceed analyst expectations, driven by strong demand for cloud services and software solutions.',
      author: 'Marcus Johnson',
      timestamp: '4 hours ago',
      image: 'linear-gradient(135deg, #f093fb 0%, #f5576c 100%)',
      comments: 1523,
      shares: 897,
      likes: 4156,
    },
    {
      id: 3,
      category: 'SCIENCE',
      title: 'Breakthrough in Quantum Computing Achieved',
      description: 'Researchers announce a major milestone in quantum computing, demonstrating practical applications that could revolutionize industries from pharmaceuticals to finance.',
      author: 'Dr. Elena Rodriguez',
      timestamp: '6 hours ago',
      image: 'linear-gradient(135deg, #4facfe 0%, #00f2fe 100%)',
      comments: 3421,
      shares: 2156,
      likes: 6789,
    },
    {
      id: 4,
      category: 'CLIMATE',
      title: 'Global Green Energy Adoption Accelerates',
      description: 'As renewable energy costs plummet, countries around the world are accelerating their transition away from fossil fuels, setting ambitious net-zero targets.',
      author: 'James Wilson',
      timestamp: '8 hours ago',
      image: 'linear-gradient(135deg, #43e97b 0%, #38f9d7 100%)',
      comments: 2198,
      shares: 1687,
      likes: 3456,
    },
    {
      id: 5,
      category: 'HEALTH',
      title: 'New Medical Treatment Shows Promise',
      description: 'Clinical trials demonstrate significant improvements in treating rare diseases, offering hope to millions of patients worldwide seeking new therapeutic options.',
      author: 'Dr. Amy Thompson',
      timestamp: '10 hours ago',
      image: 'linear-gradient(135deg, #fa709a 0%, #fee140 100%)',
      comments: 1876,
      shares: 1234,
      likes: 2945,
    },
  ];

  const handleTouchStart = (e) => {
    setTouchStart(e.targetTouches[0].clientY);
  };

  const handleTouchEnd = (e) => {
    setTouchEnd(e.changedTouches[0].clientY);
    handleSwipe();
  };

  const handleSwipe = () => {
    if (!touchStart || !touchEnd) return;
    
    const distance = touchStart - touchEnd;
    const isLeftSwipe = distance > 50;
    const isRightSwipe = distance < -50;

    if (isLeftSwipe && currentIndex < newsStories.length - 1) {
      setCurrentIndex(currentIndex + 1);
    }
    if (isRightSwipe && currentIndex > 0) {
      setCurrentIndex(currentIndex - 1);
    }
  };

  const handleKeyDown = (e) => {
    if (e.key === 'ArrowDown' && currentIndex < newsStories.length - 1) {
      setCurrentIndex(currentIndex + 1);
    }
    if (e.key === 'ArrowUp' && currentIndex > 0) {
      setCurrentIndex(currentIndex - 1);
    }
  };

  useEffect(() => {
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [currentIndex]);

  const story = newsStories[currentIndex];
  const isLiked = liked[story.id];
  const isSaved = saved[story.id];

  const toggleLike = (e) => {
    e.stopPropagation();
    setLiked((prev) => ({
      ...prev,
      [story.id]: !prev[story.id],
    }));
  };

  const toggleSave = (e) => {
    e.stopPropagation();
    setSaved((prev) => ({
      ...prev,
      [story.id]: !prev[story.id],
    }));
  };

  return (
    <div className="news-app">
      {/* Sidebar */}
      <div className="sidebar">
        <div className="logo">NEWSFLOW</div>
        
        <nav className="nav-menu">
          <div className="nav-item active">
            <Home size={20} />
            <span>For You</span>
          </div>
          <div className="nav-item">
            <Zap size={20} />
            <span>Trending</span>
          </div>
          <div className="nav-item">
            <Bell size={20} />
            <span>Saved</span>
          </div>
          <div className="nav-item">
            <Mail size={20} />
            <span>Following</span>
          </div>
        </nav>

        <div className="sidebar-footer">
          Swipe up or use arrow keys to browse
        </div>
      </div>

      {/* Main Feed */}
      <div className="main-feed">
        <div
          ref={containerRef}
          className="feed-container"
          onTouchStart={handleTouchStart}
          onTouchEnd={handleTouchEnd}
        >
          {/* Stories Container */}
          <div className="stories-container">
            {newsStories.map((s, idx) => (
              <div
                key={s.id}
                className={`story-card ${
                  idx === currentIndex
                    ? 'active'
                    : idx < currentIndex
                    ? 'prev'
                    : 'next'
                }`}
              >
                {/* Background Gradient */}
                <div
                  className="story-background"
                  style={{ background: s.image }}
                />

                {/* Overlay */}
                <div className="story-overlay" />

                {/* Content */}
                <div className="story-content">
                  {/* Top Bar */}
                  <div className="story-header">
                    <div className="header-info">
                      <span className="category-badge">{s.category}</span>
                      <span className="timestamp-badge">{s.timestamp}</span>
                    </div>
                    <div className="story-counter">
                      {currentIndex + 1} / {newsStories.length}
                    </div>
                  </div>

                  {/* Story Content */}
                  <div className="story-body">
                    <h1 className="story-title">{s.title}</h1>
                    <p className="story-description">{s.description}</p>
                    <div className="author-info">
                      <div className="author-avatar" />
                      <div>
                        <p className="author-name">{s.author}</p>
                        <p className="author-time">{s.timestamp}</p>
                      </div>
                    </div>
                  </div>

                  {/* Interaction Bar */}
                  <div className="interaction-bar">
                    <div className="action-buttons">
                      <button
                        className={`action-btn ${isLiked ? 'liked' : ''}`}
                        onClick={toggleLike}
                      >
                        <Heart
                          size={28}
                          className={`icon ${isLiked ? 'filled' : ''}`}
                        />
                        <span>{story.likes + (isLiked ? 1 : 0)}</span>
                      </button>
                      <button className="action-btn">
                        <MessageCircle size={28} />
                        <span>{s.comments}</span>
                      </button>
                      <button className="action-btn">
                        <Share2 size={28} />
                        <span>{s.shares}</span>
                      </button>
                    </div>
                    <button
                      className={`save-btn ${isSaved ? 'saved' : ''}`}
                      onClick={toggleSave}
                    >
                      <Bookmark
                        size={28}
                        className={`icon ${isSaved ? 'filled' : ''}`}
                      />
                    </button>
                  </div>
                </div>

                {/* Progress Indicator */}
                <div className="progress-bar">
                  <div
                    className="progress-fill"
                    style={{
                      width: `${((currentIndex + 1) / newsStories.length) * 100}%`,
                    }}
                  />
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Mobile Navigation Dots */}
        <div className="mobile-dots">
          {newsStories.map((_, idx) => (
            <button
              key={idx}
              className={`dot ${idx === currentIndex ? 'active' : ''}`}
              onClick={() => setCurrentIndex(idx)}
            />
          ))}
        </div>
      </div>
    </div>
  );
};

export default NewsApp;
